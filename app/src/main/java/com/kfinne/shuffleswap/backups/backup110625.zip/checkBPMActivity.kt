package com.kfinne.shuffleswap

import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.kfinne.shuffleswap.ui.components.PlaylistItem
import com.kfinne.shuffleswap.ui.components.SongResultItem
import com.kfinne.shuffleswap.viewmodel.BPMFilterViewModel

class CheckBPMinPlaylistActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val accessToken = intent.getStringExtra("ACCESS_TOKEN") ?: ""

        setContent {
            MaterialTheme {
                BPMFilterScreen(accessToken = accessToken)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BPMFilterScreen(
    accessToken: String,
    viewModel: BPMFilterViewModel = viewModel()
) {
    val context = LocalContext.current
    var fromBPM by remember { mutableStateOf("170") }
    var toBPM by remember { mutableStateOf("185") }
    var includeHalfTempo by remember { mutableStateOf(true) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    val playlists by viewModel.playlists.collectAsState()
    val selectedPlaylists by viewModel.selectedPlaylists.collectAsState()
    val filteredSongs by viewModel.filteredSongs.collectAsState()
    val isLoading by viewModel.isLoading.observeAsState(false)
    val isProcessingBPM by viewModel.isProcessingBPM.collectAsState()
    val viewModelErrorMessage by viewModel.errorMessage.observeAsState()

    // Set access token and fetch playlists on first composition
    LaunchedEffect(Unit) {
        viewModel.setAccessToken(accessToken)
        viewModel.fetchPlaylists()
    }

    // Handle ViewModel error messages
    LaunchedEffect(viewModelErrorMessage) {
        viewModelErrorMessage?.let { message ->
            errorMessage = message
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header
        Text(
            text = "BPM Filter",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold
        )

        // Error message
        errorMessage?.let { error ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.errorContainer
                )
            ) {
                Text(
                    text = error,
                    modifier = Modifier.padding(16.dp),
                    color = MaterialTheme.colorScheme.onErrorContainer
                )
            }
        }

        // Playlist Selection Section
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surfaceVariant
            )
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "Select Playlists (${selectedPlaylists.size} selected)",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold
                )

                if (isLoading) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(100.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator()
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.heightIn(max = 200.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(playlists) { playlist ->
                            PlaylistItem(
                                playlist = playlist,
                                isSelected = selectedPlaylists.contains(playlist.id),
                                onSelectionChanged = {
                                    viewModel.togglePlaylistSelection(playlist.id)
                                    errorMessage = null
                                }
                            )
                        }
                    }
                }
            }
        }

        // BPM Range Section
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surfaceVariant
            )
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    text = "BPM Range",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    OutlinedTextField(
                        value = fromBPM,
                        onValueChange = {
                            fromBPM = it
                            errorMessage = null
                        },
                        label = { Text("From BPM") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                        isError = fromBPM.toDoubleOrNull() == null && fromBPM.isNotBlank()
                    )

                    OutlinedTextField(
                        value = toBPM,
                        onValueChange = {
                            toBPM = it
                            errorMessage = null
                        },
                        label = { Text("To BPM") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                        isError = toBPM.toDoubleOrNull() == null && toBPM.isNotBlank()
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Checkbox(
                        checked = includeHalfTempo,
                        onCheckedChange = { includeHalfTempo = it }
                    )
                    Text(
                        text = "Include half/double tempo songs",
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }
        }

        // Results Section
        if (filteredSongs.isNotEmpty()) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant
                )
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "Matching Songs (${filteredSongs.size} found)",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold
                    )

                    LazyColumn(
                        modifier = Modifier.heightIn(max = 200.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(filteredSongs) { song ->
                            SongResultItem(song = song)
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.weight(1f))

        // Check Tempo Button
        Button(
            onClick = {
                Log.d("BPMFilter", "Button clicked!")
                val fromBPMValue = fromBPM.toDoubleOrNull()
                val toBPMValue = toBPM.toDoubleOrNull()

                Log.d("BPMFilter", "fromBPM: $fromBPM, toBPM: $toBPM")
                Log.d("BPMFilter", "fromBPMValue: $fromBPMValue, toBPMValue: $toBPMValue")
                Log.d("BPMFilter", "selectedPlaylists size: ${selectedPlaylists.size}")

                when {
                    selectedPlaylists.isEmpty() -> {
                        Log.d("BPMFilter", "Error: No playlists selected")
                        errorMessage = "Please select at least one playlist"
                    }
                    fromBPMValue == null || toBPMValue == null -> {
                        Log.d("BPMFilter", "Error: Invalid BPM values")
                        errorMessage = "Please enter valid BPM values"
                    }
                    fromBPMValue >= toBPMValue -> {
                        Log.d("BPMFilter", "Error: From BPM >= To BPM")
                        errorMessage = "From BPM must be less than To BPM"
                    }
                    fromBPMValue < 60 || toBPMValue > 200 -> {
                        Log.d("BPMFilter", "Error: BPM out of range")
                        errorMessage = "BPM values should be between 60 and 200"
                    }
                    else -> {
                        Log.d("BPMFilter", "Calling viewModel.checkTempo()")
                        errorMessage = null
                        viewModel.checkTempo(
                            fromBPM = fromBPMValue,
                            toBPM = toBPMValue,
                            includeHalfTempo = includeHalfTempo
                        )
                    }
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp),
            enabled = !isProcessingBPM
        ) {
            if (isProcessingBPM) {
                CircularProgressIndicator(
                    modifier = Modifier.size(20.dp),
                    color = MaterialTheme.colorScheme.onPrimary
                )
                Spacer(modifier = Modifier.width(8.dp))
            }
            Text(
                text = if (isProcessingBPM) "Checking Tempo..." else "Check Tempo",
                style = MaterialTheme.typography.titleMedium
            )
        }

        // Navigate to Results Button (if there are results)
        if (filteredSongs.isNotEmpty()) {
            Button(
                onClick = {
                    val intent = Intent(context, ResultsActivity::class.java).apply {
                        putExtra("ACCESS_TOKEN", accessToken)
                        putExtra("FILTERED_SONGS", ArrayList(filteredSongs))
                        putExtra("FROM_BPM", fromBPM)
                        putExtra("TO_BPM", toBPM)
                        putExtra("INCLUDE_HALF_TEMPO", includeHalfTempo)
                    }
                    context.startActivity(intent)
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.secondary
                )
            ) {
                Text(
                    text = "View Full Results",
                    style = MaterialTheme.typography.titleMedium
                )
            }
        }
    }
}