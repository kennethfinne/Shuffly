package com.kfinne.shuffleswap.network

import com.kfinne.shuffleswap.data.BPMResponse
import retrofit2.http.GET
import retrofit2.http.Query

interface BPMService {
    @GET("/search/")
    suspend fun getBPM(
        @Query("api_key") apiKey: String,
        @Query("type") type: String,
        @Query("lookup") lookup: String,
        @Query("limit") limit: Int = 5
    ): BPMResponse
}