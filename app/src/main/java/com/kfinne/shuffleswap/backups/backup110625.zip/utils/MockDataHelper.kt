package com.kfinne.shuffleswap.utils

import com.kfinne.shuffleswap.data.SpotifyTrack

// Mock data functions for testing
fun getMockBPM(songName: String, artist: String): Double? {
    // Mock BPM data - replace with real API calls later
    val mockBPMs = mapOf(
        "Uptown Funk" to 115.0,
        "Shape of You" to 96.0,
        "Blinding Lights" to 171.0,
        "Don't Stop Me Now" to 156.0,
        "Mr. Brightside" to 148.0,
        "Sweet Child O' Mine" to 125.0,
        "Bohemian Rhapsody" to 72.0,
        "Dancing Queen" to 100.0,
        "Billie Jean" to 117.0,
        "Hotel California" to 75.0
    )

    return mockBPMs[songName] ?: (80..180).random().toDouble()
}

fun getMockTracksFromPlaylist(playlistId: String): List<SpotifyTrack> {
    // Mock tracks data - replace with real Spotify API calls later
    val mockTracks = listOf(
        SpotifyTrack("1", "Uptown Funk", "Mark Ronson ft. Bruno Mars"),
        SpotifyTrack("2", "Shape of You", "Ed Sheeran"),
        SpotifyTrack("3", "Blinding Lights", "The Weeknd"),
        SpotifyTrack("4", "Don't Stop Me Now", "Queen"),
        SpotifyTrack("5", "Mr. Brightside", "The Killers"),
        SpotifyTrack("6", "Sweet Child O' Mine", "Guns N' Roses"),
        SpotifyTrack("7", "Bohemian Rhapsody", "Queen"),
        SpotifyTrack("8", "Dancing Queen", "ABBA"),
        SpotifyTrack("9", "Billie Jean", "Michael Jackson"),
        SpotifyTrack("10", "Hotel California", "Eagles")
    )

    // Return a subset based on playlist ID for variety
    return mockTracks.shuffled().take((5..10).random())
}