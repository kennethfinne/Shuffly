//package com.kfinne.shuffleswap
//
//// ViewModel and StateFlow
//import androidx.lifecycle.ViewModel
//import androidx.lifecycle.ViewModelProvider
//import androidx.lifecycle.viewModelScope
//import kotlinx.coroutines.flow.asStateFlow
//import kotlinx.coroutines.flow.update
//import androidx.compose.runtime.collectAsState
//import androidx.compose.runtime.LaunchedEffect
//import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
//import androidx.compose.foundation.lazy.grid.items
//import androidx.compose.foundation.layout.ColumnScope
//import androidx.compose.material.icons.filled.MonitorHeart
//import androidx.compose.material.icons.filled.Bolt
//import androidx.compose.material.icons.filled.Schedule
//import kotlinx.coroutines.launch
//import android.content.Intent
//import android.os.Bundle
//import android.widget.Toast
//import androidx.activity.compose.setContent
//import androidx.appcompat.app.AppCompatActivity
//import androidx.compose.animation.core.animateFloatAsState
//import androidx.compose.foundation.Canvas
//import androidx.compose.foundation.background
//import androidx.compose.foundation.gestures.detectDragGestures
//import androidx.compose.foundation.layout.*
//import androidx.compose.foundation.lazy.grid.GridCells
//import androidx.compose.foundation.rememberScrollState
//import androidx.compose.foundation.shape.CircleShape
//import androidx.compose.foundation.shape.RoundedCornerShape
//import androidx.compose.foundation.verticalScroll
//import androidx.compose.material.icons.Icons
//import androidx.compose.material.icons.filled.*
//import androidx.compose.material3.*
//import androidx.compose.runtime.*
//import androidx.compose.ui.Alignment
//import androidx.compose.ui.Modifier
//import androidx.compose.ui.draw.scale
//import androidx.compose.ui.geometry.Offset
//import androidx.compose.ui.graphics.Brush
//import androidx.compose.ui.graphics.Color
//import androidx.compose.ui.graphics.StrokeCap
//import androidx.compose.ui.graphics.vector.ImageVector
//import androidx.compose.ui.input.pointer.pointerInput
//import androidx.compose.ui.platform.LocalDensity
//import androidx.compose.ui.text.font.FontWeight
//import androidx.compose.ui.text.style.TextAlign
//import androidx.compose.ui.unit.dp
//import androidx.compose.ui.unit.sp
//import kotlinx.coroutines.delay
//import kotlinx.coroutines.flow.MutableStateFlow
//import kotlinx.coroutines.flow.StateFlow
//import kotlin.math.abs
//import kotlin.math.roundToInt
//
//
//// Theme and Colors
//object SpotifyTheme {
//    object Colors {
//        val Green = Color(0xFF1DB954)
//        val DarkGreen = Color(0xFF0F5132)
//        val Black = Color(0xFF000000)
//        val DarkGray = Color(0xFF121212)
//        val Gray = Color(0xFF535353)
//        val LightGray = Color(0xFFB3B3B3)
//        val White = Color(0xFFFFFFFF)
//    }
//
//    object Dimensions {
//        val paddingSmall = 8.dp
//        val paddingMedium = 16.dp
//        val paddingLarge = 32.dp
//        val iconSizeSmall = 16.dp
//        val iconSizeMedium = 24.dp
//        val iconSizeLarge = 48.dp
//        val cardRadius = 12.dp
//        val buttonHeight = 56.dp
//    }
//}
//
//// Data Models
//data class PlaylistParameters(
//    val name: String = "",
//    val songLengthRange: Pair<Float, Float> = 120f to 300f,
//    val bpmRange: Pair<Float, Float> = 80f to 140f,
//    val energy: Float = 0.5f,
//    val selectedGenres: Set<String> = emptySet()
//)
//
//data class PlaylistCreatorUiState(
//    val parameters: PlaylistParameters = PlaylistParameters(),
//    val isCreating: Boolean = false,
//    val error: String? = null,
//    val creationSuccess: Boolean = false
//)
//
//// Repository Interface
//interface SpotifyRepository {
//    suspend fun createPlaylist(parameters: PlaylistParameters): Result<String>
//}
//
//class SpotifyRepositoryImpl(private val accessToken: String) : SpotifyRepository {
//    override suspend fun createPlaylist(parameters: PlaylistParameters): Result<String> {
//        return try {
//            // Simulate API call
//            delay(2000)
//            Result.success("Playlist created successfully!")
//        } catch (e: Exception) {
//            Result.failure(e)
//        }
//    }
//}
//
//// ViewModel
//class PlaylistCreatorViewModel(
//    private val repository: SpotifyRepository
//) : ViewModel() {
//
//    private val _uiState = MutableStateFlow(PlaylistCreatorUiState())
//    val uiState: StateFlow<PlaylistCreatorUiState> = _uiState.asStateFlow()
//
//    fun updatePlaylistName(name: String) {
//        _uiState.update {
//            it.copy(parameters = it.parameters.copy(name = name))
//        }
//    }
//
//    fun updateSongLengthRange(range: Pair<Float, Float>) {
//        _uiState.update {
//            it.copy(parameters = it.parameters.copy(songLengthRange = range))
//        }
//    }
//
//    fun updateBpmRange(range: Pair<Float, Float>) {
//        _uiState.update {
//            it.copy(parameters = it.parameters.copy(bpmRange = range))
//        }
//    }
//
//    fun updateEnergy(energy: Float) {
//        _uiState.update {
//            it.copy(parameters = it.parameters.copy(energy = energy))
//        }
//    }
//
//    fun toggleGenre(genre: String) {
//        _uiState.update { state ->
//            val currentGenres = state.parameters.selectedGenres
//            val newGenres = if (currentGenres.contains(genre)) {
//                currentGenres - genre
//            } else {
//                currentGenres + genre
//            }
//            state.copy(parameters = state.parameters.copy(selectedGenres = newGenres))
//        }
//    }
//
//    fun createPlaylist() {
//        viewModelScope.launch {
//            _uiState.update { it.copy(isCreating = true, error = null) }
//
//            repository.createPlaylist(_uiState.value.parameters)
//                .onSuccess {
//                    _uiState.update {
//                        it.copy(isCreating = false, creationSuccess = true)
//                    }
//                }
//                .onFailure { error ->
//                    _uiState.update {
//                        it.copy(isCreating = false, error = error.message)
//                    }
//                }
//        }
//    }
//
//    fun clearError() {
//        _uiState.update { it.copy(error = null) }
//    }
//
//    fun resetCreationSuccess() {
//        _uiState.update { it.copy(creationSuccess = false) }
//    }
//
//    fun isValid(): Boolean {
//        val params = _uiState.value.parameters
//        return params.name.isNotBlank() && params.selectedGenres.isNotEmpty()
//    }
//}
//
//// Custom Components
//@Composable
//fun DualRangeSlider(
//    value: Pair<Float, Float>,
//    onValueChange: (Pair<Float, Float>) -> Unit,
//    valueRange: ClosedFloatingPointRange<Float> = 0f..1f,
//    modifier: Modifier = Modifier
//) {
//    val density = LocalDensity.current
//    var sliderWidth by remember { mutableStateOf(0f) }
//    val (minValue, maxValue) = value
//
//    val minPercent = (minValue - valueRange.start) / (valueRange.endInclusive - valueRange.start)
//    val maxPercent = (maxValue - valueRange.start) / (valueRange.endInclusive - valueRange.start)
//
//    Canvas(
//        modifier = modifier
//            .fillMaxWidth()
//            .height(40.dp)
//            .pointerInput(Unit) {
//                detectDragGestures { change, _ ->
//                    val newPercent = (change.position.x / sliderWidth).coerceIn(0f, 1f)
//                    val newValue = valueRange.start + newPercent * (valueRange.endInclusive - valueRange.start)
//
//                    val distanceToMin = abs(newValue - minValue)
//                    val distanceToMax = abs(newValue - maxValue)
//
//                    if (distanceToMin < distanceToMax) {
//                        if (newValue <= maxValue) {
//                            onValueChange(newValue to maxValue)
//                        }
//                    } else {
//                        if (newValue >= minValue) {
//                            onValueChange(minValue to newValue)
//                        }
//                    }
//                }
//            }
//    ) {
//        sliderWidth = size.width
//        val trackHeight = 8.dp.toPx()
//        val thumbRadius = 10.dp.toPx()
//        val centerY = size.height / 2
//
//        // Track background
//        drawLine(
//            color = SpotifyTheme.Colors.Gray,
//            start = Offset(0f, centerY),
//            end = Offset(size.width, centerY),
//            strokeWidth = trackHeight,
//            cap = StrokeCap.Round
//        )
//
//        // Active track
//        val startX = minPercent * size.width
//        val endX = maxPercent * size.width
//        drawLine(
//            color = SpotifyTheme.Colors.Green,
//            start = Offset(startX, centerY),
//            end = Offset(endX, centerY),
//            strokeWidth = trackHeight,
//            cap = StrokeCap.Round
//        )
//
//        // Thumbs
//        listOf(startX, endX).forEach { x ->
//            drawCircle(
//                color = SpotifyTheme.Colors.Green,
//                radius = thumbRadius,
//                center = Offset(x, centerY)
//            )
//            drawCircle(
//                color = SpotifyTheme.Colors.White,
//                radius = thumbRadius - 2.dp.toPx(),
//                center = Offset(x, centerY)
//            )
//        }
//    }
//}
//
//@Composable
//fun PlaylistNameSection(
//    name: String,
//    onNameChange: (String) -> Unit,
//    modifier: Modifier = Modifier
//) {
//    FormCard(
//        title = "Playlist Name",
//        modifier = modifier
//    ) {
//        OutlinedTextField(
//            value = name,
//            onValueChange = onNameChange,
//            placeholder = { Text("My Awesome Playlist", color = SpotifyTheme.Colors.Gray) },
//            colors = OutlinedTextFieldDefaults.colors(
//                focusedTextColor = SpotifyTheme.Colors.White,
//                unfocusedTextColor = SpotifyTheme.Colors.White,
//                focusedBorderColor = SpotifyTheme.Colors.Green,
//                unfocusedBorderColor = SpotifyTheme.Colors.Gray,
//                cursorColor = SpotifyTheme.Colors.Green
//            ),
//            modifier = Modifier.fillMaxWidth()
//        )
//    }
//}
//
//@Composable
//fun SongLengthSection(
//    range: Pair<Float, Float>,
//    onRangeChange: (Pair<Float, Float>) -> Unit,
//    modifier: Modifier = Modifier
//) {
//    FormCard(
//        title = "Song Length: ${formatTime(range.first)} - ${formatTime(range.second)}",
//        icon = Icons.Default.Schedule,
//        modifier = modifier
//    ) {
//        DualRangeSlider(
//            value = range,
//            onValueChange = onRangeChange,
//            valueRange = 30f..600f
//        )
//
//        Row(
//            modifier = Modifier.fillMaxWidth().padding(top = SpotifyTheme.Dimensions.paddingSmall),
//            horizontalArrangement = Arrangement.SpaceBetween
//        ) {
//            Text("0:30", color = SpotifyTheme.Colors.Gray, fontSize = 12.sp)
//            Text("10:00", color = SpotifyTheme.Colors.Gray, fontSize = 12.sp)
//        }
//    }
//}
//
//@Composable
//fun BpmSection(
//    range: Pair<Float, Float>,
//    onRangeChange: (Pair<Float, Float>) -> Unit,
//    modifier: Modifier = Modifier
//) {
//    FormCard(
//        title = "BPM Range: ${range.first.roundToInt()} - ${range.second.roundToInt()}",
//        icon = Icons.Default.MonitorHeart,
//        modifier = modifier
//    ) {
//        DualRangeSlider(
//            value = range,
//            onValueChange = onRangeChange,
//            valueRange = 60f..200f
//        )
//
//        Row(
//            modifier = Modifier.fillMaxWidth().padding(top = SpotifyTheme.Dimensions.paddingSmall),
//            horizontalArrangement = Arrangement.SpaceBetween
//        ) {
//            Text("60", color = SpotifyTheme.Colors.Gray, fontSize = 12.sp)
//            Text("200", color = SpotifyTheme.Colors.Gray, fontSize = 12.sp)
//        }
//    }
//}
//
//@Composable
//fun EnergySection(
//    energy: Float,
//    onEnergyChange: (Float) -> Unit,
//    modifier: Modifier = Modifier
//) {
//    val energyLabels = remember {
//        mapOf(
//            0.0f to "Mellow", 0.2f to "Chill", 0.4f to "Moderate",
//            0.6f to "Upbeat", 0.8f to "High Energy", 1.0f to "Maximum"
//        )
//    }
//
//    val energyLabel = energyLabels.entries.minByOrNull { abs(it.key - energy) }?.value ?: "Custom"
//
//    FormCard(
//        title = "Energy Level: $energyLabel",
//        icon = Icons.Default.Bolt,
//        modifier = modifier
//    ) {
//        Slider(
//            value = energy,
//            onValueChange = onEnergyChange,
//            valueRange = 0f..1f,
//            colors = SliderDefaults.colors(
//                thumbColor = SpotifyTheme.Colors.Green,
//                activeTrackColor = SpotifyTheme.Colors.Green,
//                inactiveTrackColor = SpotifyTheme.Colors.Gray
//            )
//        )
//
//        Row(
//            modifier = Modifier.fillMaxWidth(),
//            horizontalArrangement = Arrangement.SpaceBetween
//        ) {
//            Text("Mellow", color = SpotifyTheme.Colors.Gray, fontSize = 12.sp)
//            Text("Maximum", color = SpotifyTheme.Colors.Gray, fontSize = 12.sp)
//        }
//    }
//}
//
//@Composable
//fun GenresSection(
//    selectedGenres: Set<String>,
//    onGenreToggle: (String) -> Unit,
//    modifier: Modifier = Modifier
//) {
//    val genres = remember {
//        listOf(
//            "Pop", "Rock", "Hip Hop", "Electronic", "Jazz", "Classical",
//            "R&B", "Country", "Reggae", "Alternative", "Indie", "Folk"
//        )
//    }
//
//    FormCard(
//        title = "Genres (${selectedGenres.size} selected)",
//        modifier = modifier
//    ) {
//        LazyVerticalGrid(
//            columns = GridCells.Fixed(2),
//            horizontalArrangement = Arrangement.spacedBy(SpotifyTheme.Dimensions.paddingSmall),
//            verticalArrangement = Arrangement.spacedBy(SpotifyTheme.Dimensions.paddingSmall),
//            modifier = Modifier.height(200.dp)
//        ) {
//            items(genres) { genre ->
//                GenreButton(
//                    genre = genre,
//                    isSelected = selectedGenres.contains(genre),
//                    onClick = { onGenreToggle(genre) }
//                )
//            }
//        }
//    }
//}
//
//@Composable
//fun GenreButton(
//    genre: String,
//    isSelected: Boolean,
//    onClick: () -> Unit,
//    modifier: Modifier = Modifier
//) {
//    val scale by animateFloatAsState(
//        targetValue = if (isSelected) 1.05f else 1f,
//        label = "scale"
//    )
//
//    Button(
//        onClick = onClick,
//        colors = ButtonDefaults.buttonColors(
//            containerColor = if (isSelected) SpotifyTheme.Colors.Green
//            else SpotifyTheme.Colors.Gray.copy(alpha = 0.5f),
//            contentColor = SpotifyTheme.Colors.White
//        ),
//        modifier = modifier.fillMaxWidth().scale(scale),
//        shape = RoundedCornerShape(8.dp)
//    ) {
//        Text(
//            text = genre,
//            fontSize = 12.sp,
//            fontWeight = FontWeight.Medium
//        )
//    }
//}
//
//@Composable
//fun FormCard(
//    title: String,
//    modifier: Modifier = Modifier,
//    icon: ImageVector? = null,
//    content: @Composable ColumnScope.() -> Unit
//) {
//    Card(
//        modifier = modifier.fillMaxWidth(),
//        colors = CardDefaults.cardColors(
//            containerColor = SpotifyTheme.Colors.DarkGray.copy(alpha = 0.5f)
//        ),
//        shape = RoundedCornerShape(SpotifyTheme.Dimensions.cardRadius)
//    ) {
//        Column(modifier = Modifier.padding(SpotifyTheme.Dimensions.paddingMedium)) {
//            Row(
//                verticalAlignment = Alignment.CenterVertically,
//                modifier = Modifier.padding(bottom = 12.dp)
//            ) {
//                icon?.let {
//                    Icon(
//                        imageVector = it,
//                        contentDescription = null,
//                        tint = SpotifyTheme.Colors.Green,
//                        modifier = Modifier.size(SpotifyTheme.Dimensions.iconSizeSmall)
//                    )
//                    Spacer(modifier = Modifier.width(SpotifyTheme.Dimensions.paddingSmall))
//                }
//                Text(
//                    text = title,
//                    color = SpotifyTheme.Colors.Green,
//                    fontSize = 14.sp,
//                    fontWeight = FontWeight.Medium
//                )
//            }
//            content()
//        }
//    }
//}
//
//@Composable
//fun PlaylistPreview(
//    parameters: PlaylistParameters,
//    modifier: Modifier = Modifier
//) {
//    val energyLabels = mapOf(
//        0.0f to "Mellow", 0.2f to "Chill", 0.4f to "Moderate",
//        0.6f to "Upbeat", 0.8f to "High Energy", 1.0f to "Maximum"
//    )
//    val energyLabel = energyLabels.entries.minByOrNull { abs(it.key - parameters.energy) }?.value ?: "Custom"
//
//    Card(
//        modifier = modifier.fillMaxWidth(),
//        colors = CardDefaults.cardColors(
//            containerColor = SpotifyTheme.Colors.DarkGray.copy(alpha = 0.3f)
//        ),
//        shape = RoundedCornerShape(SpotifyTheme.Dimensions.cardRadius)
//    ) {
//        Column(modifier = Modifier.padding(SpotifyTheme.Dimensions.paddingMedium)) {
//            Text(
//                text = "Preview",
//                color = SpotifyTheme.Colors.Green,
//                fontSize = 14.sp,
//                fontWeight = FontWeight.Medium,
//                modifier = Modifier.padding(bottom = SpotifyTheme.Dimensions.paddingSmall)
//            )
//
//            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
//                Text("Name: ${parameters.name}", color = SpotifyTheme.Colors.LightGray, fontSize = 12.sp)
//                Text("Length: ${formatTime(parameters.songLengthRange.first)} - ${formatTime(parameters.songLengthRange.second)}", color = SpotifyTheme.Colors.LightGray, fontSize = 12.sp)
//                Text("BPM: ${parameters.bpmRange.first.roundToInt()} - ${parameters.bpmRange.second.roundToInt()}", color = SpotifyTheme.Colors.LightGray, fontSize = 12.sp)
//                Text("Energy: $energyLabel", color = SpotifyTheme.Colors.LightGray, fontSize = 12.sp)
//                Text("Genres: ${parameters.selectedGenres.joinToString(", ")}", color = SpotifyTheme.Colors.LightGray, fontSize = 12.sp)
//            }
//        }
//    }
//}
//
//// Main Activity
//class SpotifyPlaylistCreator : AppCompatActivity() {
//    private lateinit var viewModel: PlaylistCreatorViewModel
//
//    private val getSongBPM_API_key = "fd972355de33b6723a6ee71ea40edc4f"
//    private val getSongBPM_API_URL = "https://api.getsong.co/"
//
//    override fun onCreate(savedInstanceState: Bundle?) {
//        super.onCreate(savedInstanceState)
//
//        val accessToken = intent.getStringExtra("ACCESS_TOKEN") ?: ""
//        if (accessToken.isEmpty()) {
//            Toast.makeText(this, "Authentication error. Please log in again.", Toast.LENGTH_SHORT).show()
//            navigateToMain()
//            return
//        }
//
//        val repository = SpotifyRepositoryImpl(accessToken)
//        viewModel = ViewModelProvider(
//            this,
//            object : ViewModelProvider.Factory {
//                override fun <T : ViewModel> create(modelClass: Class<T>): T {
//                    @Suppress("UNCHECKED_CAST")
//                    return PlaylistCreatorViewModel(repository) as T
//                }
//            }
//        )[PlaylistCreatorViewModel::class.java]
//
//        setContent {
//            MaterialTheme {
//                PlaylistCreatorScreen(viewModel = viewModel)
//            }
//        }
//    }
//
//    private fun navigateToMain() {
//        val intent = Intent(this, MainActivity::class.java)
//        startActivity(intent)
//        finish()
//    }
//}
//
//// Main Screen Composable
//@Composable
//fun PlaylistCreatorScreen(
//    viewModel: PlaylistCreatorViewModel
//) {
//    val uiState by viewModel.uiState.collectAsState()
//
//    // Handle side effects
//    LaunchedEffect(uiState.error) {
//        uiState.error?.let {
//            // Show error snackbar or handle error
//            viewModel.clearError()
//        }
//    }
//
//    LaunchedEffect(uiState.creationSuccess) {
//        if (uiState.creationSuccess) {
//            // Show success message
//            viewModel.resetCreationSuccess()
//        }
//    }
//
//    Box(
//        modifier = Modifier
//            .fillMaxSize()
//            .background(
//                brush = Brush.verticalGradient(
//                    colors = listOf(
//                        SpotifyTheme.Colors.DarkGreen,
//                        SpotifyTheme.Colors.Black,
//                        SpotifyTheme.Colors.DarkGreen
//                    )
//                )
//            )
//    ) {
//        Column(
//            modifier = Modifier
//                .fillMaxSize()
//                .padding(SpotifyTheme.Dimensions.paddingMedium)
//                .verticalScroll(rememberScrollState()),
//            horizontalAlignment = Alignment.CenterHorizontally
//        ) {
//            // Header
//            PlaylistCreatorHeader()
//
//            // Form sections
//            Column(
//                verticalArrangement = Arrangement.spacedBy(SpotifyTheme.Dimensions.paddingMedium),
//                modifier = Modifier.fillMaxWidth()
//            ) {
//                PlaylistNameSection(
//                    name = uiState.parameters.name,
//                    onNameChange = viewModel::updatePlaylistName
//                )
//
//                SongLengthSection(
//                    range = uiState.parameters.songLengthRange,
//                    onRangeChange = viewModel::updateSongLengthRange
//                )
//
//                BpmSection(
//                    range = uiState.parameters.bpmRange,
//                    onRangeChange = viewModel::updateBpmRange
//                )
//
//                EnergySection(
//                    energy = uiState.parameters.energy,
//                    onEnergyChange = viewModel::updateEnergy
//                )
//
//                GenresSection(
//                    selectedGenres = uiState.parameters.selectedGenres,
//                    onGenreToggle = viewModel::toggleGenre
//                )
//
//                CreatePlaylistButton(
//                    isEnabled = viewModel.isValid() && !uiState.isCreating,
//                    isCreating = uiState.isCreating,
//                    onClick = viewModel::createPlaylist
//                )
//
//                if (viewModel.isValid()) {
//                    PlaylistPreview(parameters = uiState.parameters)
//                }
//            }
//        }
//    }
//}
//
//@Composable
//fun PlaylistCreatorHeader() {
//    Row(
//        verticalAlignment = Alignment.CenterVertically,
//        modifier = Modifier.padding(bottom = SpotifyTheme.Dimensions.paddingSmall)
//    ) {
//        Box(
//            modifier = Modifier
//                .size(SpotifyTheme.Dimensions.iconSizeLarge)
//                .background(SpotifyTheme.Colors.Green, CircleShape),
//            contentAlignment = Alignment.Center
//        ) {
//            Icon(
//                imageVector = Icons.Filled.MusicNote,
//                contentDescription = null,
//                tint = SpotifyTheme.Colors.White,
//                modifier = Modifier.size(SpotifyTheme.Dimensions.iconSizeMedium)
//            )
//        }
//        Spacer(modifier = Modifier.width(SpotifyTheme.Dimensions.paddingSmall))
//        Text(
//            text = "Playlist Creator",
//            fontSize = 24.sp,
//            fontWeight = FontWeight.Bold,
//            color = SpotifyTheme.Colors.White
//        )
//    }
//
//    Text(
//        text = "Create the perfect playlist with custom parameters",
//        color = SpotifyTheme.Colors.Green,
//        fontSize = 14.sp,
//        textAlign = TextAlign.Center,
//        modifier = Modifier.padding(bottom = SpotifyTheme.Dimensions.paddingLarge)
//    )
//}
//
//@Composable
//fun CreatePlaylistButton(
//    isEnabled: Boolean,
//    isCreating: Boolean,
//    onClick: () -> Unit,
//    modifier: Modifier = Modifier
//) {
//    Button(
//        onClick = onClick,
//        enabled = isEnabled,
//        colors = ButtonDefaults.buttonColors(
//            containerColor = if (isEnabled) SpotifyTheme.Colors.Green else SpotifyTheme.Colors.Gray,
//            contentColor = SpotifyTheme.Colors.White,
//            disabledContainerColor = SpotifyTheme.Colors.Gray,
//            disabledContentColor = SpotifyTheme.Colors.Gray
//        ),
//        modifier = modifier
//            .fillMaxWidth()
//            .height(SpotifyTheme.Dimensions.buttonHeight),
//        shape = RoundedCornerShape(SpotifyTheme.Dimensions.cardRadius)
//    ) {
//        if (isCreating) {
//            CircularProgressIndicator(
//                modifier = Modifier.size(SpotifyTheme.Dimensions.iconSizeMedium),
//                color = SpotifyTheme.Colors.White,
//                strokeWidth = 2.dp
//            )
//        } else {
//            Row(verticalAlignment = Alignment.CenterVertically) {
//                Icon(
//                    imageVector = Icons.Default.Add,
//                    contentDescription = null,
//                    modifier = Modifier.size(20.dp)
//                )
//                Spacer(modifier = Modifier.width(SpotifyTheme.Dimensions.paddingSmall))
//                Text(
//                    text = "Create Playlist",
//                    fontSize = 16.sp,
//                    fontWeight = FontWeight.Bold
//                )
//            }
//        }
//    }
//}
//
//// Utility Functions
//fun formatTime(seconds: Float): String {
//    val mins = (seconds / 60).toInt()
//    val secs = (seconds % 60).toInt()
//    return "$mins:${secs.toString().padStart(2, '0')}"
//}