package com.kfinne.shuffleswap

import android.content.ComponentName
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.View
import android.widget.ArrayAdapter
import android.widget.ImageButton
import android.widget.ListView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.android.volley.toolbox.JsonObjectRequest
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import com.google.android.material.color.MaterialColors
import com.google.android.material.progressindicator.LinearProgressIndicator
import com.google.android.material.snackbar.Snackbar
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import com.google.android.material.textview.MaterialTextView
import com.google.gson.Gson
import okhttp3.Call
import okhttp3.Callback
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import okhttp3.Response
import org.json.JSONObject
import java.io.IOException

class SpotifyPlaylistsActivity : AppCompatActivity() {

    private lateinit var playlistsListView: ListView
    private lateinit var selectedPlaylistsCard: MaterialCardView
    private lateinit var selectedPlaylistsText: MaterialTextView
    private lateinit var shuffleButton: MaterialButton
    private lateinit var progressIndicator: LinearProgressIndicator
    private lateinit var rootLayout: View
    private lateinit var accessToken: String
    private val httpClient = OkHttpClient()
    private val gson = Gson()

    // Playlist name input components
    private lateinit var playlistNameCard: MaterialCardView
    private lateinit var playlistNameInputLayout: TextInputLayout
    private lateinit var playlistNameEditText: TextInputEditText

    private val selectedPlaylists = mutableListOf<Playlist>()
    private val allPlaylists = mutableListOf<Playlist>()

    // Add this property to store user ID
    private var spotifyUserId: String? = null

    companion object {
        const val TAG = "SpotifyPlaylists"
        const val PLAYLISTS_API_URL = "https://api.spotify.com/v1/me/playlists"
        const val QUEUE_API_URL = "https://api.spotify.com/v1/me/player/queue"
        const val PLAYER_API_URL = "https://api.spotify.com/v1/me/player"
        const val SHUFFLE_PLAYLIST_NAME = "ShuffleMix"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_spotify_playlists)

        initializeViews()
        setupMaterialTheming()

        val backButton = findViewById<ImageButton>(R.id.backButton)
        backButton.setOnClickListener {
            finish()
        }

        accessToken = intent.getStringExtra("ACCESS_TOKEN") ?: ""

        if (accessToken.isEmpty()) {
            showMaterialSnackbar("Authentication error. Please log in again.", isError = true)
            navigateToMain()
            return
        }

        setupViews()
        fetchPlaylists()
    }

    private fun initializeViews() {
        playlistsListView = findViewById(R.id.playlistsListView)
        selectedPlaylistsCard = findViewById(R.id.selectedPlaylistsCard)
        selectedPlaylistsText = findViewById(R.id.selectedPlaylistsText)
        shuffleButton = findViewById(R.id.shuffleButton)
        progressIndicator = findViewById(R.id.progressIndicator)
        rootLayout = findViewById(R.id.rootLayout)

        // Initialize playlist name input components
        playlistNameCard = findViewById(R.id.playlistNameCard)
        playlistNameInputLayout = findViewById(R.id.playlistNameInputLayout)
        playlistNameEditText = findViewById(R.id.playlistNameEditText)
    }

    private fun setupMaterialTheming() {
        // Set up Material Design colors and styling
        val surfaceColor = MaterialColors.getColor(this, com.google.android.material.R.attr.colorSurface, "")
        val primaryColor = MaterialColors.getColor(this, com.google.android.material.R.attr.colorPrimary, "")

        selectedPlaylistsCard.setCardBackgroundColor(surfaceColor)
        selectedPlaylistsCard.elevation = 8f
        selectedPlaylistsCard.radius = 16f

        // Configure progress indicator
        progressIndicator.setIndicatorColor(primaryColor)
        progressIndicator.trackColor = MaterialColors.getColor(this, com.google.android.material.R.attr.colorSurfaceVariant, "")
        progressIndicator.visibility = View.GONE
    }

    private fun setupViews() {
        selectedPlaylistsText.text = "Select 2 playlists to shuffle"
        updateShuffleButtonState(false, "Shuffle")

        // Set default playlist name
        playlistNameEditText.setText(SHUFFLE_PLAYLIST_NAME)

        shuffleButton.setOnClickListener {
            if (selectedPlaylists.size == 2) {
                shuffleAndCreatePlaylist()
            }
        }

        // Add Material Design ripple effect and styling to button
        shuffleButton.icon = ContextCompat.getDrawable(this, R.drawable.ic_shuffle) // You'll need to add this icon
        shuffleButton.iconGravity = MaterialButton.ICON_GRAVITY_START
    }

    private fun updateShuffleButtonState(enabled: Boolean, text: String, isLoading: Boolean = false) {
        shuffleButton.isEnabled = enabled
        shuffleButton.text = text

        if (isLoading) {
            progressIndicator.visibility = View.VISIBLE
            shuffleButton.icon = null
        } else {
            progressIndicator.visibility = View.GONE
            shuffleButton.icon = ContextCompat.getDrawable(this, R.drawable.ic_shuffle)
        }
    }

    private fun showMaterialSnackbar(message: String, isError: Boolean = false) {
        val snackbar = Snackbar.make(rootLayout, message,
            if (isError) Snackbar.LENGTH_LONG else Snackbar.LENGTH_SHORT)

        if (isError) {
            snackbar.setBackgroundTint(MaterialColors.getColor(this, com.google.android.material.R.attr.colorError, ""))
            snackbar.setTextColor(MaterialColors.getColor(this, com.google.android.material.R.attr.colorOnError, ""))
        } else {
            snackbar.setBackgroundTint(MaterialColors.getColor(this, com.google.android.material.R.attr.colorPrimary, ""))
            snackbar.setTextColor(MaterialColors.getColor(this, com.google.android.material.R.attr.colorOnPrimary, ""))
        }

        snackbar.show()
    }

    private fun fetchPlaylists() {
        updateShuffleButtonState(false, "Loading...", true)

        val request = Request.Builder()
            .url(PLAYLISTS_API_URL)
            .addHeader("Authorization", "Bearer $accessToken")
            .build()

        httpClient.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.e(TAG, "Failed to fetch playlists: ${e.message}")
                runOnUiThread {
                    updateShuffleButtonState(false, "Shuffle")
                    showMaterialSnackbar("Network error: ${e.message}", true)
                }
            }

            override fun onResponse(call: Call, response: Response) {
                response.use {
                    if (response.isSuccessful) {
                        try {
                            val responseBody = response.body?.string()
                            val playlistsResponse = gson.fromJson(responseBody, PlaylistsResponse::class.java)
                            allPlaylists.clear()
                            allPlaylists.addAll(playlistsResponse.items)

                            runOnUiThread {
                                updateShuffleButtonState(false, "Shuffle")
                                if (allPlaylists.isNotEmpty()) {
                                    setupPlaylistSelection()
                                } else {
                                    showMaterialSnackbar("No playlists found")
                                }
                            }
                        } catch (e: Exception) {
                            Log.e(TAG, "Error parsing response: ${e.message}")
                            runOnUiThread {
                                updateShuffleButtonState(false, "Shuffle")
                                showMaterialSnackbar("Error loading playlists", true)
                            }
                        }
                    } else {
                        Log.e(TAG, "API error: ${response.code}")
                        runOnUiThread {
                            updateShuffleButtonState(false, "Shuffle")
                            if (response.code == 401) {
                                showMaterialSnackbar("Session expired. Please log in again.", true)
                                navigateToMain()
                            } else {
                                showMaterialSnackbar("Failed to load playlists", true)
                            }
                        }
                    }
                }
            }
        })
    }

    private fun updatePlaylistNameInputState(isActive: Boolean) {
        if (isActive) {
            // Active state - Green
            shuffleButton.backgroundTintList = ContextCompat.getColorStateList(this, R.color.colorPrimary)
            shuffleButton.strokeColor = ContextCompat.getColorStateList(this, R.color.colorPrimary)

        } else {
            // Inactive state - Gray
            shuffleButton.backgroundTintList = ContextCompat.getColorStateList(this, R.color.card_background)
            shuffleButton.strokeColor = ContextCompat.getColorStateList(this, R.color.placeholder_border)

        }
    }

    private fun setupPlaylistSelection() {
        val playlistNames = allPlaylists.map { "${it.name} (${it.tracks.total} songs)" }
        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_multiple_choice, playlistNames)
        playlistsListView.adapter = adapter
        playlistsListView.choiceMode = ListView.CHOICE_MODE_MULTIPLE

        // Add Material Design styling to ListView items
        playlistsListView.dividerHeight = 1
        playlistsListView.divider = ContextCompat.getDrawable(this, R.drawable.material_divider)

        playlistsListView.setOnItemClickListener { _, _, position, _ ->
            val playlist = allPlaylists[position]

            if (selectedPlaylists.contains(playlist)) {
                selectedPlaylists.remove(playlist)
            } else if (selectedPlaylists.size < 2) {
                selectedPlaylists.add(playlist)
            } else {
                showMaterialSnackbar("You can only select 2 playlists")
                playlistsListView.setItemChecked(position, false)
                return@setOnItemClickListener
            }

            updateSelectedPlaylistsDisplay()
        }
    }

    private fun updateSelectedPlaylistsDisplay() {
        when (selectedPlaylists.size) {
            0 -> {
                selectedPlaylistsText.text = "Select 2 playlists to shuffle"
                selectedPlaylistsCard.alpha = 0.6f
                updateShuffleButtonState(false, "Shuffle")
                updatePlaylistNameInputState(false) // Gray state
            }
            1 -> {
                selectedPlaylistsText.text = "Selected:\n• ${selectedPlaylists[0].name}\nSelect 1 more playlist"
                selectedPlaylistsCard.alpha = 0.8f
                updateShuffleButtonState(false, "Shuffle")
                updatePlaylistNameInputState(false) // Gray state
            }
            2 -> {
                selectedPlaylistsText.text = "Selected:\n• ${selectedPlaylists[0].name}\n• ${selectedPlaylists[1].name}"
                selectedPlaylistsCard.alpha = 1.0f
                updateShuffleButtonState(true, "Shuffle")
                updatePlaylistNameInputState(true) // Green state
            }
        }
    }

    private fun shuffleAndCreatePlaylist() {
        updateShuffleButtonState(false, "Loading tracks...", true)

        fetchPlaylistTracks(selectedPlaylists[0]) { tracks1 ->
            fetchPlaylistTracks(selectedPlaylists[1]) { tracks2 ->
                runOnUiThread {
                    createAlternatingTracksAndPlaylist(tracks1, tracks2)
                }
            }
        }
    }

    private fun fetchPlaylistTracks(playlist: Playlist, callback: (List<Track>) -> Unit) {
        val url = "https://api.spotify.com/v1/playlists/${playlist.id}/tracks?fields=items(track(id,name,artists(name),uri))"
        val request = Request.Builder()
            .url(url)
            .addHeader("Authorization", "Bearer $accessToken")
            .build()

        httpClient.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.e(TAG, "Failed to fetch tracks for ${playlist.name}: ${e.message}")
                runOnUiThread {
                    showMaterialSnackbar("Failed to load tracks from ${playlist.name}", true)
                    resetShuffleButton()
                }
            }

            override fun onResponse(call: Call, response: Response) {
                response.use {
                    if (response.isSuccessful) {
                        try {
                            val responseBody = response.body?.string()
                            val tracksResponse = gson.fromJson(responseBody, PlaylistTracksResponse::class.java)
                            val tracks = tracksResponse.items.mapNotNull { it.track }.filter { it.uri != null }
                            callback(tracks)
                        } catch (e: Exception) {
                            Log.e(TAG, "Error parsing tracks for ${playlist.name}: ${e.message}")
                            runOnUiThread {
                                showMaterialSnackbar("Error parsing tracks from ${playlist.name}", true)
                                resetShuffleButton()
                            }
                        }
                    } else {
                        Log.e(TAG, "Failed to fetch tracks: ${response.code}")
                        runOnUiThread {
                            showMaterialSnackbar("Failed to load tracks", true)
                            resetShuffleButton()
                        }
                    }
                }
            }
        })
    }

    private fun createAlternatingTracksAndPlaylist(tracks1: List<Track>, tracks2: List<Track>) {
        if (tracks1.isEmpty() || tracks2.isEmpty()) {
            showMaterialSnackbar("One or both playlists have no playable tracks", true)
            resetShuffleButton()
            return
        }

        // Shuffle both lists
        val shuffled1 = tracks1.shuffled()
        val shuffled2 = tracks2.shuffled()

        // Create alternating list (max 20 songs)
        val mixedTracks = mutableListOf<Track>()
        val maxSongs = 20
        var fromList1 = true

        for (i in 0 until maxSongs) {
            val track = if (fromList1 && shuffled1.isNotEmpty()) {
                shuffled1[i % shuffled1.size]
            } else if (!fromList1 && shuffled2.isNotEmpty()) {
                shuffled2[i % shuffled2.size]
            } else {
                break
            }
            mixedTracks.add(track)
            fromList1 = !fromList1
        }

        // Create/update playlist instead of queueing
        createShuffledPlaylist(mixedTracks)
    }

    private fun createShuffledPlaylist(tracks: List<Track>) {
        updateShuffleButtonState(false, "Getting user info...", true)

        // First get user ID
        getUserId { userId ->
            if (userId != null) {
                spotifyUserId = userId
                // Get the custom playlist name from the input field
                val customPlaylistName = playlistNameEditText.text.toString().trim().ifEmpty { SHUFFLE_PLAYLIST_NAME }

                // Check if playlist with this name already exists
                findExistingPlaylist(customPlaylistName) { existingPlaylistId ->
                    if (existingPlaylistId != null) {
                        // Clear existing playlist and add new tracks
                        runOnUiThread {
                            updateShuffleButtonState(false, "Updating playlist...", true)
                        }
                        clearAndUpdatePlaylist(existingPlaylistId, tracks)
                    } else {
                        // Create new playlist
                        runOnUiThread {
                            updateShuffleButtonState(false, "Creating playlist...", true)
                        }
                        createNewPlaylist(tracks, customPlaylistName)
                    }
                }
            } else {
                runOnUiThread {
                    showMaterialSnackbar("Failed to get user information", true)
                    resetShuffleButton()
                }
            }
        }
    }

    private fun getUserId(callback: (String?) -> Unit) {
        val request = Request.Builder()
            .url("https://api.spotify.com/v1/me")
            .addHeader("Authorization", "Bearer $accessToken")
            .build()

        httpClient.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.e(TAG, "Failed to get user info: ${e.message}")
                callback(null)
            }

            override fun onResponse(call: Call, response: Response) {
                response.use {
                    if (response.isSuccessful) {
                        try {
                            val responseBody = response.body?.string()
                            val userResponse = gson.fromJson(responseBody, UserResponse::class.java)
                            callback(userResponse.id)
                        } catch (e: Exception) {
                            Log.e(TAG, "Error parsing user info: ${e.message}")
                            callback(null)
                        }
                    } else {
                        Log.e(TAG, "Failed to get user info: ${response.code}")
                        callback(null)
                    }
                }
            }
        })
    }

    private fun findExistingPlaylist(playlistName: String, callback: (String?) -> Unit) {
        val request = Request.Builder()
            .url(PLAYLISTS_API_URL)
            .addHeader("Authorization", "Bearer $accessToken")
            .build()

        httpClient.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.e(TAG, "Failed to search for existing playlist: ${e.message}")
                callback(null)
            }

            override fun onResponse(call: Call, response: Response) {
                response.use {
                    if (response.isSuccessful) {
                        try {
                            val responseBody = response.body?.string()
                            val playlistsResponse = gson.fromJson(responseBody, PlaylistsResponse::class.java)
                            val existingPlaylist = playlistsResponse.items.find { it.name == playlistName }
                            callback(existingPlaylist?.id)
                        } catch (e: Exception) {
                            Log.e(TAG, "Error finding existing playlist: ${e.message}")
                            callback(null)
                        }
                    } else {
                        callback(null)
                    }
                }
            }
        })
    }

    private fun createNewPlaylist(tracks: List<Track>, playlistName: String = SHUFFLE_PLAYLIST_NAME) {
        val playlistData = mapOf(
            "name" to playlistName,
            "description" to "Mixed playlist created by ShuffleSwap",
            "public" to false
        )

        val jsonBody = gson.toJson(playlistData)
        Log.d(TAG, "Creating playlist with data: $jsonBody")
        Log.d(TAG, "Using user ID: $spotifyUserId")

        val requestBody = RequestBody.create(
            "application/json".toMediaType(),
            jsonBody
        )

        val request = Request.Builder()
            .url("https://api.spotify.com/v1/users/$spotifyUserId/playlists")
            .addHeader("Authorization", "Bearer $accessToken")
            .addHeader("Content-Type", "application/json")
            .post(requestBody)
            .build()

        Log.d(TAG, "Create playlist URL: ${request.url}")

        httpClient.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.e(TAG, "Failed to create playlist: ${e.message}")
                runOnUiThread {
                    showMaterialSnackbar("Network error creating playlist: ${e.message}", true)
                    resetShuffleButton()
                }
            }

            override fun onResponse(call: Call, response: Response) {
                response.use {
                    val responseBody = response.body?.string()
                    Log.d(TAG, "Create playlist response code: ${response.code}")
                    Log.d(TAG, "Create playlist response: $responseBody")

                    if (response.isSuccessful) {
                        try {
                            val playlistResponse = gson.fromJson(responseBody, Playlist::class.java)
                            runOnUiThread {
                                updateShuffleButtonState(false, "Adding tracks...", true)
                            }
                            addTracksToPlaylist(playlistResponse.id, tracks, playlistName)
                        } catch (e: Exception) {
                            Log.e(TAG, "Error parsing created playlist: ${e.message}")
                            Log.e(TAG, "Response was: $responseBody")
                            runOnUiThread {
                                showMaterialSnackbar("Error parsing playlist response", true)
                                resetShuffleButton()
                            }
                        }
                    } else {
                        Log.e(TAG, "Failed to create playlist: ${response.code}")
                        Log.e(TAG, "Error response: $responseBody")
                        runOnUiThread {
                            val errorMsg = when (response.code) {
                                401 -> "Authentication failed - please log in again"
                                403 -> "Permission denied - check Spotify app permissions"
                                400 -> "Invalid request - check playlist data"
                                else -> "Failed to create playlist (${response.code})"
                            }
                            showMaterialSnackbar(errorMsg, true)
                            resetShuffleButton()
                        }
                    }
                }
            }
        })
    }

    private fun clearAndUpdatePlaylist(playlistId: String, tracks: List<Track>) {
        // First, clear the existing playlist
        val clearRequest = Request.Builder()
            .url("https://api.spotify.com/v1/playlists/$playlistId/tracks")
            .addHeader("Authorization", "Bearer $accessToken")
            .addHeader("Content-Type", "application/json")
            .method("PUT", RequestBody.create("application/json".toMediaType(), "{\"uris\":[]}"))
            .build()

        httpClient.newCall(clearRequest).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.e(TAG, "Failed to clear playlist: ${e.message}")
                runOnUiThread {
                    showMaterialSnackbar("Failed to clear existing playlist", true)
                    resetShuffleButton()
                }
            }

            override fun onResponse(call: Call, response: Response) {
                response.use {
                    if (response.isSuccessful) {
                        runOnUiThread {
                            updateShuffleButtonState(false, "Adding new tracks...", true)
                        }
                        val customPlaylistName = playlistNameEditText.text.toString().trim().ifEmpty { SHUFFLE_PLAYLIST_NAME }
                        addTracksToPlaylist(playlistId, tracks, customPlaylistName)
                    } else {
                        Log.e(TAG, "Failed to clear playlist: ${response.code}")
                        runOnUiThread {
                            showMaterialSnackbar("Failed to clear existing playlist", true)
                            resetShuffleButton()
                        }
                    }
                }
            }
        })
    }

    private fun addTracksToPlaylist(playlistId: String, tracks: List<Track>, playlistName: String = SHUFFLE_PLAYLIST_NAME) {
        val trackUris = tracks.mapNotNull { it.uri }
        if (trackUris.isEmpty()) {
            runOnUiThread {
                showMaterialSnackbar("No valid tracks to add", true)
                resetShuffleButton()
            }
            return
        }

        val requestData = mapOf("uris" to trackUris)
        val requestBody = RequestBody.create(
            "application/json".toMediaType(),
            gson.toJson(requestData)
        )

        val request = Request.Builder()
            .url("https://api.spotify.com/v1/playlists/$playlistId/tracks")
            .addHeader("Authorization", "Bearer $accessToken")
            .addHeader("Content-Type", "application/json")
            .post(requestBody)
            .build()

        httpClient.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.e(TAG, "Failed to add tracks to playlist: ${e.message}")
                runOnUiThread {
                    showMaterialSnackbar("Failed to add tracks to playlist", true)
                    resetShuffleButton()
                }
            }

            override fun onResponse(call: Call, response: Response) {
                response.use {
                    if (response.isSuccessful) {
                        runOnUiThread {
                            showMaterialSnackbar("Successfully created '$playlistName' with ${tracks.size} songs!")
                            shuffleButton.text = "Open Spotify"
                            shuffleButton.icon = ContextCompat.getDrawable(this@SpotifyPlaylistsActivity, R.drawable.ic_spotify)
                            shuffleButton.isEnabled = true
                            progressIndicator.visibility = View.GONE
                            shuffleButton.setOnClickListener {
                                openSpotify(playlistName)
                            }
                        }
                    } else {
                        Log.e(TAG, "Failed to add tracks: ${response.code}")
                        runOnUiThread {
                            showMaterialSnackbar("Failed to add tracks to playlist", true)
                            resetShuffleButton()
                        }
                    }
                }
            }
        })
    }

    private fun openSpotify(playlistId: String) {
        try {
            // Open Spotify first
            val intent = Intent().apply {
                action = Intent.ACTION_MAIN
                addCategory(Intent.CATEGORY_LAUNCHER)
                component = ComponentName("com.spotify.music", "com.spotify.music.MainActivity")
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }

            if (intent.resolveActivity(packageManager) != null) {
                startActivity(intent)

                // Wait a moment for Spotify to load, then use Web API
                Handler(Looper.getMainLooper()).postDelayed({
                    playPlaylistViaWebApi(playlistId)
                }, 5000) // 2 second delay

            } else {
                val playStoreIntent = Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=com.spotify.music"))
                startActivity(playStoreIntent)
            }
        } catch (e: Exception) {
            showMaterialSnackbar("Could not open Spotify")
        }
    }

    // COMPLETE VERSION - Actually sends the request
    private fun playPlaylistViaWebApi(playlistId: String) {
        // Create the JSON request body
        val playRequest = JSONObject().apply {
            put("context_uri", "spotify:playlist:$playlistId")
            put("position_ms", 0)
        }

        // THIS IS WHAT WAS MISSING - Actually send the HTTP request:
        // Using your existing accessToken variable

        val request = object : JsonObjectRequest(
            Method.PUT,
            "https://api.spotify.com/v1/me/player/play",
            playRequest,
            { response ->
                // Success
                showMaterialSnackbar("Playing playlist!")
            },
            { error ->
                // Error
                showMaterialSnackbar("Failed to play: ${error.message}")
            }
        ) {
            override fun getHeaders(): MutableMap<String, String> {
                return mutableMapOf(
                    "Authorization" to "Bearer $accessToken",
                    "Content-Type" to "application/json"
                )
            }
        }
    }

    // OR if you're using a different HTTP library (like OkHttp):
    private fun playPlaylistViaWebApiOkHttp(playlistId: String) {
        val playRequest = JSONObject().apply {
            put("context_uri", "spotify:playlist:$playlistId")
            put("position_ms", 0)
        }

        val requestBody = RequestBody.create(
            "application/json".toMediaTypeOrNull(),
            playRequest.toString()
        )

        val request = Request.Builder()
            .url("https://api.spotify.com/v1/me/player/play")
            .put(requestBody)
            .addHeader("Authorization", "Bearer $accessToken")
            .addHeader("Content-Type", "application/json")
            .build()

        httpClient.newCall(request).enqueue(object : Callback {
            override fun onResponse(call: Call, response: Response) {
                runOnUiThread {
                    showMaterialSnackbar("Playing playlist!")
                }
            }

            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread {
                    showMaterialSnackbar("Failed to play playlist")
                }
            }
        })
    }

    private fun resetShuffleButton() {
        updateShuffleButtonState(selectedPlaylists.size == 2, "Shuffle & Create Playlist")
        shuffleButton.setOnClickListener {
            if (selectedPlaylists.size == 2) {
                shuffleAndCreatePlaylist()
            }
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        finish() // Går tilbake til forrige Activity
        return true
    }

    private fun navigateToMain() {
        val intent = Intent(this, MainActivity::class.java)
        startActivity(intent)
        finish()
    }

    // Data models remain the same
    data class PlaylistsResponse(val items: List<Playlist>)

    data class Playlist(
        val id: String,
        val name: String,
        val tracks: TracksInfo
    )

    data class TracksInfo(val total: Int)

    data class PlaylistTracksResponse(val items: List<TrackItem>)

    data class TrackItem(val track: Track?)

    data class Track(
        val id: String?,
        val name: String,
        val uri: String?,
        val artists: List<Artist>
    )

    data class Artist(val name: String)

    data class DevicesResponse(val devices: List<Device>)

    data class Device(
        val id: String,
        val is_active: Boolean,
        val name: String,
        val type: String
    )

    data class UserResponse(val id: String)
}