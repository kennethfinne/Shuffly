package com.kfinne.shuffleswap.viewmodel

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.gson.Gson
import com.kfinne.shuffleswap.SpotifyPlaylistsActivity
import com.kfinne.shuffleswap.data.*
import com.kfinne.shuffleswap.network.BPMService
import com.kfinne.shuffleswap.utils.getMockBPM
import com.kfinne.shuffleswap.utils.getMockTracksFromPlaylist
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.*
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.io.IOException



class BPMFilterViewModel : ViewModel() {
    private val _playlists = MutableStateFlow<List<Playlist>>(emptyList())
    val playlists: StateFlow<List<Playlist>> = _playlists

    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> = _isLoading

    private val _errorMessage = MutableLiveData<String?>()
    val errorMessage: LiveData<String?> = _errorMessage

    private val _selectedPlaylists = MutableStateFlow<Set<String>>(emptySet())
    val selectedPlaylists: StateFlow<Set<String>> = _selectedPlaylists

    private val _filteredSongs = MutableStateFlow<List<Song>>(emptyList())
    val filteredSongs: StateFlow<List<Song>> = _filteredSongs

    private val _isProcessingBPM = MutableStateFlow<Boolean>(false)
    val isProcessingBPM: StateFlow<Boolean> = _isProcessingBPM

    private val httpClient = OkHttpClient()
    private val gson = Gson()
    private val bpmService = createBPMService()

    private val allPlaylists = mutableListOf<Playlist>()
    private lateinit var accessToken: String

    fun setAccessToken(token: String) {
        accessToken = token
    }

    fun fetchPlaylists() {
        _isLoading.value = true
        _errorMessage.value = null

        val request = Request.Builder()
            .url(PLAYLISTS_API_URL)
            .addHeader("Authorization", "Bearer $accessToken")
            .build()

        httpClient.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.e("BPMFilterViewModel", "Failed to fetch playlists: ${e.message}")
                _isLoading.postValue(false)
                _errorMessage.postValue("Network error: ${e.message}")
            }

            override fun onResponse(call: Call, response: Response) {
                response.use {
                    if (response.isSuccessful) {
                        try {
                            val responseBody = response.body?.string()
                            val playlistsResponse = gson.fromJson(responseBody, PlaylistsResponse::class.java)
                            allPlaylists.clear()
                            allPlaylists.addAll(playlistsResponse.items)

                            _isLoading.postValue(false)
                            _playlists.value = allPlaylists.toList()
                        } catch (e: Exception) {
                            Log.e("BPMFilterViewModel", "Error parsing response: ${e.message}")
                            _isLoading.postValue(false)
                            _errorMessage.postValue("Error loading playlists")
                        }
                    } else {
                        Log.e("BPMFilterViewModel", "API error: ${response.code}")
                        _isLoading.postValue(false)
                        when (response.code) {
                            401 -> _errorMessage.postValue("Session expired. Please log in again.")
                            else -> _errorMessage.postValue("Failed to load playlists")
                        }
                    }
                }
            }
        })
    }

    fun togglePlaylistSelection(playlistId: String) {
        val currentSelection = _selectedPlaylists.value.toMutableSet()
        if (currentSelection.contains(playlistId)) {
            currentSelection.remove(playlistId)
        } else if (currentSelection.size < 2) {
            currentSelection.add(playlistId)
        } else {
            _errorMessage.value = "You can only select 2 playlists"
            return
        }
        _selectedPlaylists.value = currentSelection
    }

    fun checkTempo(
        fromBPM: Double,
        toBPM: Double,
        includeHalfTempo: Boolean
    ) {
        viewModelScope.launch {
            _isProcessingBPM.value = true
            _filteredSongs.value = emptyList()
            _errorMessage.value = null

            try {
                val filteredSongs = mutableListOf<Song>()
                val selectedPlaylistIds = _selectedPlaylists.value
                val selectedPlaylistData = _playlists.value.filter { it.id in selectedPlaylistIds }

                for (playlist in selectedPlaylistData) {
                    try {
                        val tracks = getTracksFromSpotifyPlaylist(playlist.id)

                        for (track in tracks) {
                            val artistName = track.artists.firstOrNull()?.name ?: "Unknown Artist"
                            val bpm = getBPMFromAPI(track.name, artistName)

                            if (bpm != null) {
                                val isInRange = bpm in fromBPM..toBPM
                                val isHalfTempoInRange = includeHalfTempo && (bpm / 2) in fromBPM..toBPM
                                val isDoubleTempoInRange = includeHalfTempo && (bpm * 2) in fromBPM..toBPM

                                if (isInRange || isHalfTempoInRange || isDoubleTempoInRange) {
                                    // Only add songs that have valid IDs
                                    track.id?.let { trackId ->
                                        filteredSongs.add(
                                            Song(
                                                id = trackId,
                                                name = track.name ?: "Unknown Title",
                                                artist = artistName,
                                                bpm = bpm,
                                                playlistName = playlist.name
                                            )
                                        )
                                    }
                                }
                            }
                        }
                    } catch (e: Exception) {
                        Log.e("BPMFilterViewModel", "Error processing playlist ${playlist.name}: ${e.message}")
                        _errorMessage.value = "Failed to load tracks from ${playlist.name}"
                    }
                }

                _filteredSongs.value = filteredSongs
            } catch (e: Exception) {
                Log.e("BPMFilterViewModel", "Error in checkTempo: ${e.message}")
                _errorMessage.value = "Error processing playlists: ${e.message}"
            } finally {
                _isProcessingBPM.value = false
            }
        }
    }

    private suspend fun getTracksFromSpotifyPlaylist(playlistId: String): List<SpotifyPlaylistsActivity.Track> {
        return withContext(Dispatchers.IO) {
            try {
                val url = "https://api.spotify.com/v1/playlists/$playlistId/tracks?fields=items(track(id,name,artists(name),uri))"
                val request = Request.Builder()
                    .url(url)
                    .addHeader("Authorization", "Bearer $accessToken")
                    .build()

                val response = httpClient.newCall(request).execute()

                response.use {
                    if (response.isSuccessful) {
                        val responseBody = response.body?.string()
                        val tracksResponse = gson.fromJson(responseBody, SpotifyPlaylistsActivity.PlaylistTracksResponse::class.java)
                        tracksResponse.items.mapNotNull { it.track }.filter { it.uri != null }
                    } else {
                        Log.e("BPMFilterViewModel", "Failed to fetch tracks: ${response.code}")
                        throw IOException("Failed to fetch tracks: ${response.code}")
                    }
                }
            } catch (e: Exception) {
                Log.e("BPMFilterViewModel", "Error fetching tracks: ${e.message}")
                throw e
            }
        }
    }

    // For future real API implementation
    private suspend fun getBPMFromAPI(songName: String, artist: String): Double? {
        return try {
            Log.d("BPMFilterViewModel", "Fetching BPM for: $artist - $songName")

            // You need to add your API key here
            val apiKey = "fd972355de33b6723a6ee71ea40edc4f" // Get this from GetSongBPM
            val lookupQuery = "song:${songName.trim()} artist:${artist.trim()}"

            val response = bpmService.getBPM(
                apiKey = apiKey,
                type = "both",
                lookup = lookupQuery
            )

            val bpm = response.search?.firstOrNull()?.tempo?.toDoubleOrNull()

            Log.d("Lookup", lookupQuery)
            Log.d("Response", response.toString())
            Log.d("BPMFilterViewModel", "BPM result: $bpm")
            bpm
        } catch (e: retrofit2.HttpException) {
            Log.e("BPMFilterViewModel", "HTTP error ${e.code()} for $artist - $songName: ${e.message()}")
            null
        } catch (e: Exception) {
            Log.e("BPMFilterViewModel", "Error fetching BPM for $artist - $songName: ${e.message}")
            null
        }
    }


    private fun createBPMService(): BPMService {
        return Retrofit.Builder()
            .baseUrl("https://api.getsong.co/") // Verify this URL
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(BPMService::class.java)
    }

    fun clearError() {
        _errorMessage.value = null
    }

    companion object {
        private const val PLAYLISTS_API_URL = "https://api.spotify.com/v1/me/playlists"
    }
}